This Mavlink LoRa ROS node has been tested under ROS Kinetic and ROS Melodic
